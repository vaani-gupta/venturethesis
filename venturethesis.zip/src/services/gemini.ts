import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface AgentResponse {
  role: string;
  content: any;
}

export interface Blueprint {
  title: string;
  pitch: {
    problem: string;
    solution: string;
    valueProp: string;
  };
  lab: {
    trl: number;
    viability: number;
    resources: Array<{ item: string; category: string; cost: string }>;
    techSpecs: string;
  };
  market: {
    revenueStrategy: string;
    competitorGap: string;
    targetMarket: string;
  };
  talentBridge: Array<{ role: string; description: string; priority: 'High' | 'Medium' | 'Low' }>;
  roadmap: {
    nextSteps: string[];
    grantMatches: string[];
  };
  sourceBacklinks: Array<{ claim: string; reference: string }>;
}

const MODEL_NAME = "gemini-3.1-pro-preview";

export async function runBoardroom(paperText: string): Promise<Blueprint> {
  // 1. The Scientist
  const scientistTask = ai.models.generateContent({
    model: MODEL_NAME,
    contents: `You are The Scientist. Analyze this academic paper text and extract the core technical claims, methodology, and limitations. 
    Paper Text: ${paperText.substring(0, 30000)}`, // Truncate if too long
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          claims: { type: Type.ARRAY, items: { type: Type.STRING } },
          methodology: { type: Type.STRING },
          limitations: { type: Type.ARRAY, items: { type: Type.STRING } },
          sourceBacklinks: { 
            type: Type.ARRAY, 
            items: { 
              type: Type.OBJECT, 
              properties: { 
                claim: { type: Type.STRING }, 
                reference: { type: Type.STRING, description: "e.g. Page 4, Para 2" } 
              } 
            } 
          }
        }
      }
    }
  });

  // 2. The Engineer
  const engineerTask = ai.models.generateContent({
    model: MODEL_NAME,
    contents: `You are The Engineer. Assess the Technology Readiness Level (TRL 1-9) and build a "Resource Shopping List" (hardware, software, chemicals) based on the methodology. 
    IMPORTANT: All costs MUST be estimated in Indian Rupees (₹).
    Paper Text: ${paperText.substring(0, 30000)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          trl: { type: Type.INTEGER },
          viability: { type: Type.INTEGER, description: "0-100 percentage" },
          resources: { 
            type: Type.ARRAY, 
            items: { 
              type: Type.OBJECT, 
              properties: { 
                item: { type: Type.STRING }, 
                category: { type: Type.STRING }, 
                cost: { type: Type.STRING, description: "Estimated cost range in ₹ (INR)" } 
              } 
            } 
          },
          techSpecs: { type: Type.STRING }
        }
      }
    }
  });

  // 3. The MBA
  const mbaTask = ai.models.generateContent({
    model: MODEL_NAME,
    contents: `You are The MBA. Develop revenue models (SaaS, Licensing, etc.) and market differentiation based on this research. 
    Also, identify exactly which experts/co-founders are needed to bridge the gap between the Lab and the Market (e.g., "Biotech Researcher", "Hardware Architect").
    Paper Text: ${paperText.substring(0, 30000)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          revenueStrategy: { type: Type.STRING },
          competitorGap: { type: Type.STRING },
          targetMarket: { type: Type.STRING },
          valueProp: { type: Type.STRING },
          talentNeeds: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                role: { type: Type.STRING },
                description: { type: Type.STRING },
                priority: { type: Type.STRING, description: "High, Medium, or Low" }
              }
            }
          }
        }
      }
    }
  });

  // 4. The Risk Evaluator
  const riskTask = ai.models.generateContent({
    model: MODEL_NAME,
    contents: `You are The Risk Evaluator. Conduct a "Pre-Mortem" to identify technical and market bottlenecks. Suggest next steps and grant matches.
    Paper Text: ${paperText.substring(0, 30000)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          bottlenecks: { type: Type.ARRAY, items: { type: Type.STRING } },
          nextSteps: { type: Type.ARRAY, items: { type: Type.STRING } },
          grantMatches: { type: Type.ARRAY, items: { type: Type.STRING } }
        }
      }
    }
  });

  const [sciRes, engRes, mbaRes, riskRes] = await Promise.all([
    scientistTask,
    engineerTask,
    mbaTask,
    riskTask
  ]);

  const sciData = JSON.parse(sciRes.text);
  const engData = JSON.parse(engRes.text);
  const mbaData = JSON.parse(mbaRes.text);
  const riskData = JSON.parse(riskRes.text);

  // Final Consolidation
  const consolidationTask = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: `Consolidate the following agent reports into a final Startup Blueprint JSON.
    Scientist: ${JSON.stringify(sciData)}
    Engineer: ${JSON.stringify(engData)}
    MBA: ${JSON.stringify(mbaData)}
    Risk: ${JSON.stringify(riskData)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          pitch: {
            type: Type.OBJECT,
            properties: {
              problem: { type: Type.STRING },
              solution: { type: Type.STRING },
              valueProp: { type: Type.STRING }
            }
          },
          lab: {
            type: Type.OBJECT,
            properties: {
              trl: { type: Type.INTEGER },
              viability: { type: Type.INTEGER },
              resources: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT, 
                  properties: { 
                    item: { type: Type.STRING }, 
                    category: { type: Type.STRING }, 
                    cost: { type: Type.STRING } 
                  } 
                } 
              },
              techSpecs: { type: Type.STRING }
            }
          },
          market: {
            type: Type.OBJECT,
            properties: {
              revenueStrategy: { type: Type.STRING },
              competitorGap: { type: Type.STRING },
              targetMarket: { type: Type.STRING }
            }
          },
          talentBridge: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                role: { type: Type.STRING },
                description: { type: Type.STRING },
                priority: { type: Type.STRING }
              }
            }
          },
          roadmap: {
            type: Type.OBJECT,
            properties: {
              nextSteps: { type: Type.ARRAY, items: { type: Type.STRING } },
              grantMatches: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          },
          sourceBacklinks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                claim: { type: Type.STRING },
                reference: { type: Type.STRING }
              }
            }
          }
        }
      }
    }
  });

  return JSON.parse(consolidationTask.text);
}
